from brownie import accounts, ABC, Bar, Foo, Migrations


def main():
    acct = accounts[0]
    Foo.deploy({"from": acct})
    Bar.deploy({"from": acct})
    ABC.deploy({"from": acct})
    Migrations.deploy({"from": acct})



