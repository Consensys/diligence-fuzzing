const VulnerableToken = artifacts.require("VulnerableToken");

module.exports = function(deployer) {
    deployer.deploy(VulnerableToken);
};
