const Foo = artifacts.require("Foo");
const Bar = artifacts.require("Bar");
const ABC = artifacts.require("ABC");

module.exports = function(deployer) {
    deployer.deploy(Foo);
    deployer.deploy(Bar);
    deployer.deploy(ABC);
};