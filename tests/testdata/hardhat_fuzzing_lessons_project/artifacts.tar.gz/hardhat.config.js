require("@nomiclabs/hardhat-waffle");

/**
 * @type import('hardhat/config').HardhatUserConfig
 */

module.exports = {
    defaultNetwork: "localhost",
    networks: {
        localhost: {
            url: `http://localhost:7545/`,
            accounts: "remote",
            live: false,
            saveDeployments: true,
            tags: ["local"],
        },
    },
    solidity: "0.8.15",
};